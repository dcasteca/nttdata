import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { typeDoc } from '../shared/models/typeDoc';
import { constants } from '../shared/constants/constant';


@Component({
  selector: 'app-root',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.scss']
})
export class FormularioComponent implements OnInit {
  tipoDoc: string = constants.valueCedula;
  numDoc: number = 0;

  docs: typeDoc[] = [
    { value: constants.valueCedula, viewValue: constants.Cedula },
    { value: constants.valuePasaporte, viewValue: constants.Pasaporte },
  ];
  ngOnInit(): void {

  }
  constructor(private router: Router) {
  }

  onClick() {
    this.router.navigate([constants.pathResultado, this.tipoDoc, this.numDoc]);
  }
}
