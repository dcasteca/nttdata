import { Component, OnInit } from '@angular/core';

interface Doc {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  tipoDoc: string="C";
  numDoc: number=0;


  docs: Doc[] = [
    {value: "C", viewValue: 'Cédula de ciudadanía'},
    {value: "P", viewValue: 'Pasaporte'},
  ];
  ngOnInit(): void {

  }
  constructor(){
  }

  onChange($event:any) {
    console.log(this.tipoDoc);


  }
}
