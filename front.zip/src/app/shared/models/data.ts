
export interface Data {
  primerNombre: string;
  segundoNombre: string;
  primerApellido: string;
  segundoApellido: string;
  telefono: string;
  direccion: string;
  ciudadResidencia: string;
}
