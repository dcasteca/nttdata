export interface typeDoc {
  value: string;
  viewValue: string;
}
