export interface Doc {
  tipDoc: string;
  numDoc: string;
}
