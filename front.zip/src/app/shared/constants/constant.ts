export const constants = {
  alertDatos: "Datos no encontrados",
  valueCedula: "C",
  valuePasaporte: "P",
  Cedula: "Cédula de ciudadanía",
  Pasaporte: "Pasaporte",
  pathResultado: "resultado"
};
