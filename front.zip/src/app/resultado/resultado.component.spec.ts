import { ResultadoComponent } from './resultado.component';
import { TestBed } from '@angular/core/testing';


describe('ResultadoComponent', () => {

  let component: ResultadoComponent;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ResultadoComponent]
    });
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('prueba',()=>{

  })
});
