import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService } from 'src/services/dataService/data.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import {Doc} from './../shared/models/doc';
import {Data} from './../shared/models/data';
import {constants} from './../shared/constants/constant';

@Component({
  selector: 'app-resultado',
  templateUrl: './resultado.component.html',
  styleUrls: ['./resultado.component.scss']
})

export class ResultadoComponent implements OnInit {

  doc: Doc = {
    tipDoc: "",
    numDoc: ""
  };
  data: Data = {
    primerNombre: "",
    segundoNombre: "",
    primerApellido: "",
    segundoApellido: "",
    telefono: "",
    direccion: "",
    ciudadResidencia: ""
  }

  constructor(
    private router: Router,
    private rutaActiva: ActivatedRoute,
    private dataService: DataService
  ) { }

  ngOnInit(): void {
    this.rutaActiva.params.subscribe((params: any) => {
      this.doc.tipDoc = params.tipDoc;
      this.doc.numDoc = params.numDoc;
    });
    this.getData();
  }

  getData() {
    this.dataService.getData(this.doc.tipDoc, this.doc.numDoc).subscribe((data: any) => {
      console.log(data);
      if (data.error != null) {
        Swal.fire(data.error)
      } else if (data.primerNombre == null) {
        Swal.fire(constants.alertDatos);
      } else {
        this.data.primerNombre = data.primerNombre;
        this.data.segundoNombre = data.segundoNombre;
        this.data.primerApellido = data.primerApellido;
        this.data.segundoApellido = data.segundoApellido;
        this.data.telefono = data.telefono;
        this.data.direccion = data.direccion;
        this.data.ciudadResidencia = data.ciudadResidencia;
      }
    }, (error) => {
      Swal.fire(error.error.status + ": " + error.error.error)
    });
  }

  onClick() {
    this.router.navigate(['']);
  }

}
