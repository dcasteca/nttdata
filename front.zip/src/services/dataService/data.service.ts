import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http: HttpClient) { }

  getData(tipDoc: string, numDoc: string) :Observable<any> {
    const variables = { numDoc:numDoc,tipoDoc: tipDoc };
    console.log(variables);
    const params = new HttpParams({ fromObject: variables });
    console.log(params);
    const url = `http://localhost:8090/api/prueba`;
    console.log(url);
    return this.http.get<any>(url, {params: params});
  }
}
