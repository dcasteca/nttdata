package com.nttdata.prueba.model.common.enums;

public enum ExceptionTypeEnum {
    APPLICATION
}
