package com.nttdata.prueba.model.common.contact;

import com.nttdata.prueba.model.common.enums.ExceptionTypeEnum;

public interface IExceptionEnum {
    String name();
    String getCode();
    ExceptionTypeEnum getType();
}
