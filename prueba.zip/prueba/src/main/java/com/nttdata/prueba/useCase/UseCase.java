package com.nttdata.prueba.useCase;

import com.nttdata.prueba.entryPoints.error.RestExceptionHandler;
import com.nttdata.prueba.model.response.ResponsePrueba;
import org.springframework.http.ResponseEntity;

import java.math.BigInteger;

public class UseCase {

    public ResponseEntity<Object> consultarDatos(String numDoc, String tipoDoc) {

        if (numDoc.isBlank() || tipoDoc.isBlank() || !isNumeric(numDoc) || (!tipoDoc.equals("C") && !tipoDoc.equals("P"))) {
            return new RestExceptionHandler().handleMethodArgumentNotValid();
        }

        return numDoc.trim().equals("23445322") ? ResponseEntity.ok(
                new ResponsePrueba().builder()
                        .primerNombre("Daniel")
                        .segundoNombre("Camilo")
                        .primerApellido("Castellanos")
                        .segundoApellido("Carreno")
                        .telefono(new BigInteger("3223653541"))
                        .direccion("Calle 1 # 1 - 1")
                        .ciudadResidencia("Bogota")
                        .build()) : ResponseEntity.ok(new ResponsePrueba().builder().build());
    }

    public boolean isNumeric(String cadena) {
        boolean resultado;
        try {
            Integer.parseInt(cadena);
            resultado = true;
        } catch (NumberFormatException excepcion) {
            resultado = false;
        }
        return resultado;
    }
}
