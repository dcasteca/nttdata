package com.nttdata.prueba.entryPoints.controller;

import com.nttdata.prueba.useCase.UseCase;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api", produces = MediaType.APPLICATION_JSON_VALUE)
@AllArgsConstructor
public class PruebaContoller {

    @GetMapping(path = "/health", produces = {MediaType.APPLICATION_JSON_VALUE})
    public String home() {
        return "All ok";
    }

    @GetMapping(path = {"/prueba"}, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> getData(@RequestParam(value = "numDoc") String numDoc,
                                          @RequestParam(value = "tipoDoc") String tipoDoc) {
        return new UseCase().consultarDatos(numDoc, tipoDoc);
    }
}
