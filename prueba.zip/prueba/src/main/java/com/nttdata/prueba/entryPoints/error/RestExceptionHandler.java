package com.nttdata.prueba.entryPoints.error;

import com.nttdata.prueba.model.common.contact.IExceptionEnum;
import com.nttdata.prueba.model.common.enums.ApplicationExceptionEnum;
import com.nttdata.prueba.model.response.ResponseError;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;

import static org.springframework.http.MediaType.APPLICATION_JSON;

@Slf4j
@RestControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {

    @Override
    public ResponseEntity<Object> handleMissingServletRequestParameter(
            MissingServletRequestParameterException exception,
            HttpHeaders headers, HttpStatus status, WebRequest request
    ) {
        return getResponseEntity(ApplicationExceptionEnum.BAD_REQUEST,
                HttpStatus.BAD_REQUEST);
    }

    public ResponseEntity<Object> handleMethodArgumentNotValid() {
        return getResponseEntity(ApplicationExceptionEnum.REQUEST_INVALID_PARAMS,
                HttpStatus.BAD_REQUEST);
    }

    @Override
    public ResponseEntity<Object> handleNoHandlerFoundException(
            NoHandlerFoundException exception,
            HttpHeaders headers, HttpStatus status, WebRequest request
    ) {
        return getResponseEntity(
                ApplicationExceptionEnum.NOT_FOUND,
                HttpStatus.NOT_FOUND);
    }

    @Override
    public ResponseEntity<Object> handleHttpRequestMethodNotSupported(
            HttpRequestMethodNotSupportedException exception,
            HttpHeaders headers, HttpStatus status, WebRequest request
    ) {
        return getResponseEntity(ApplicationExceptionEnum.METHOD_NOT_ALLOWED,
                status);
    }

    private ResponseEntity<Object> getResponseEntity(IExceptionEnum code, HttpStatus status) {
        final var body = ResponseError.builder()
                .error(code.getCode())
                .timestamp(LocalDateTime.now().toString())
                .status(status.value())
                .build();

        return ResponseEntity
                .status(status)
                .contentType(APPLICATION_JSON)
                .body(body);
    }
}
