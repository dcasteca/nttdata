package com.nttdata.prueba.model.common.enums;

import com.nttdata.prueba.model.common.contact.IExceptionEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ApplicationExceptionEnum implements IExceptionEnum {

    METHOD_NOT_ALLOWED("Método no permitido."),
    NOT_FOUND("Método no encontrado."),
    BAD_REQUEST("Solicitud incorrecta."),
    REQUEST_INVALID_PARAMS("Los parámetros de la solicitud están incompletos o errados.");

    private static final ExceptionTypeEnum TYPE = ExceptionTypeEnum.APPLICATION;
    private final String code;

    @Override
    public ExceptionTypeEnum getType() {
        return TYPE;
    }
}