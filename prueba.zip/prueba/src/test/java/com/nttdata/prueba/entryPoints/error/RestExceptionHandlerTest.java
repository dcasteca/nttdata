package com.nttdata.prueba.entryPoints.error;

import com.nttdata.prueba.model.common.enums.ApplicationExceptionEnum;
import com.nttdata.prueba.model.response.ResponseError;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.util.Objects;

import static java.util.Arrays.asList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(SpringExtension.class)
class RestExceptionHandlerTest {

    @InjectMocks
    RestExceptionHandler restExceptionHandler;

    @Test
    void missingServletRequestParameterHandler() {
        var ex = new MissingServletRequestParameterException("param", "type");

        final var actual = restExceptionHandler.handleMissingServletRequestParameter(
                ex, new HttpHeaders(), HttpStatus.BAD_REQUEST, requestStub()
        );

        assertNotNull(actual);
        assertEquals(HttpStatus.BAD_REQUEST.value(), actual.getStatusCodeValue());
        assertEquals(
                ApplicationExceptionEnum.BAD_REQUEST.getCode(),
                ((ResponseError) Objects.requireNonNull(actual.getBody())).getError()
        );
    }

    @Test
    void noHandlerFoundExceptionHandler() {
        var req = new ServletServerHttpRequest(new MockHttpServletRequest(HttpMethod.GET.name(), "/resource"));
        var ex = new NoHandlerFoundException(
                HttpMethod.GET.name(), req.getServletRequest().getRequestURI(), req.getHeaders()
        );
        var actual = restExceptionHandler.handleNoHandlerFoundException(
                ex, new HttpHeaders(), HttpStatus.NOT_FOUND, requestStub()
        );
        assertNotNull(actual);
        assertEquals(HttpStatus.NOT_FOUND.value(), actual.getStatusCodeValue());
        assertEquals(
                ApplicationExceptionEnum.NOT_FOUND.getCode(),
                ((ResponseError) Objects.requireNonNull(actual.getBody())).getError()
        );
    }

    @Test
    void methodNotAAllowedHandler() {
        final var exception = new HttpRequestMethodNotSupportedException("POST", asList("GET", "DELETE"));

        final var actual = restExceptionHandler.handleHttpRequestMethodNotSupported(
                exception, new HttpHeaders(), HttpStatus.METHOD_NOT_ALLOWED, requestStub()
        );

        assertNotNull(actual);
        assertEquals(HttpStatus.METHOD_NOT_ALLOWED.value(), actual.getStatusCodeValue());

        assertEquals(
                ApplicationExceptionEnum.METHOD_NOT_ALLOWED.getCode(),
                ((ResponseError) Objects.requireNonNull(actual.getBody())).getError()
        );
    }


    WebRequest requestStub() {
        return new ServletWebRequest(new MockHttpServletRequest("GET", "/"), new MockHttpServletResponse());
    }
}