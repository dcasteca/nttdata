package com.nttdata.prueba.model.response;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class ResponseErrorTest {

    private String timestamp;
    private Integer status;
    private String error;

    @BeforeEach
    void setup(){
        error = "Método no permitido.";
        timestamp = LocalDateTime.now().toString();
        status = 400;
    }

    @Test
    void responseTest(){
        ResponseError responseError = ResponseError.builder()
                .error(error)
                .timestamp(timestamp)
                .status(status)
                .build();

        Assertions.assertAll("Fields",
                () -> Assertions.assertEquals(error, responseError.getError()),
                () -> Assertions.assertEquals(timestamp, responseError.getTimestamp()),
                () -> Assertions.assertEquals(status, responseError.getStatus()));
    }
}