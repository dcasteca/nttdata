package com.nttdata.prueba.model.common.enums;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ApplicationExceptionEnumTest {

    ApplicationExceptionEnum[] applicationExceptionEnums;

    @BeforeEach
    void setup(){
        applicationExceptionEnums = new ApplicationExceptionEnum[] {
                ApplicationExceptionEnum.METHOD_NOT_ALLOWED,
                ApplicationExceptionEnum.NOT_FOUND,
                ApplicationExceptionEnum.BAD_REQUEST,
                ApplicationExceptionEnum.REQUEST_INVALID_PARAMS
        };
    }

    @Test
    void supportedExceptionValuesTest(){
        Assertions.assertArrayEquals(applicationExceptionEnums, ApplicationExceptionEnum.values());
    }

    @Test
    void codeErrorMethodNotAllowedTest(){
        Assertions.assertEquals("Método no permitido.", ApplicationExceptionEnum.METHOD_NOT_ALLOWED.getCode());
    }

    @Test
    void codeErrorNotFoundTest(){
        Assertions.assertEquals("Método no encontrado.", ApplicationExceptionEnum.NOT_FOUND.getCode());
    }

    @Test
    void codeErrorBadRequestTest(){
        Assertions.assertEquals("Solicitud incorrecta.", ApplicationExceptionEnum.BAD_REQUEST.getCode());
    }

    @Test
    void codeErrorRequestInvalidParamsTest(){
        Assertions.assertEquals("Los parámetros de la solicitud están incompletos o errados.", ApplicationExceptionEnum.REQUEST_INVALID_PARAMS.getCode());
    }
}