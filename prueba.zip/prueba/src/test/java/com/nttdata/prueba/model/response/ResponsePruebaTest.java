package com.nttdata.prueba.model.response;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigInteger;

class ResponsePruebaTest {

    private String primerNombre;
    private String segundoNombre;
    private String primerApellido;
    private String segundoApellido;
    private BigInteger telefono;
    private String direccion;
    private String ciudadResidencia;

    @BeforeEach
    void setup() {

        primerNombre = "Daniel";
        segundoNombre = "Camilo";
        primerApellido = "Castellanos";
        segundoApellido = "Carreno";
        telefono = new BigInteger("3223653541");
        direccion = "Calle 1 # 1 - 1";
        ciudadResidencia = "Bogota";
    }

    @Test
    void responseTest() {
        ResponsePrueba response = new ResponsePrueba().builder()
                .primerNombre(primerNombre)
                .segundoNombre(segundoNombre)
                .primerApellido(primerApellido)
                .segundoApellido(segundoApellido)
                .telefono(telefono)
                .direccion(direccion)
                .ciudadResidencia(ciudadResidencia)
                .build();

        Assertions.assertAll("Fields",
                () -> Assertions.assertEquals(primerNombre, response.getPrimerNombre()),
                () -> Assertions.assertEquals(segundoNombre, response.getSegundoNombre()),
                () -> Assertions.assertEquals(primerApellido, response.getPrimerApellido()),
                () -> Assertions.assertEquals(segundoApellido, response.getSegundoApellido()),
                () -> Assertions.assertEquals(telefono, response.getTelefono()),
                () -> Assertions.assertEquals(direccion, response.getDireccion()),
                () -> Assertions.assertEquals(ciudadResidencia, response.getCiudadResidencia()));
    }
}