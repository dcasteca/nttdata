package com.nttdata.prueba.useCase;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class UseCaseTest {

    @Test
    void getIsNumericOk() throws Exception {
        UseCase useCase = new UseCase();
        Assertions.assertEquals(true, useCase.isNumeric("1"));
    }
    @Test
    void getIsNumericKo() throws Exception {
        UseCase useCase = new UseCase();
        Assertions.assertEquals(false, useCase.isNumeric("1a"));
    }
}