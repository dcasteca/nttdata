package com.nttdata.prueba.model.common.enums;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ExceptionTypeEnumTest {
    ExceptionTypeEnum[] exceptionTypeEnums;

    @BeforeEach
    void setup() {
        exceptionTypeEnums = new ExceptionTypeEnum[]{
                ExceptionTypeEnum.APPLICATION
        };
    }

    @Test
    void supportedTypeExceptionValuesTest() {
        Assertions.assertArrayEquals(exceptionTypeEnums, ExceptionTypeEnum.values());
    }
}