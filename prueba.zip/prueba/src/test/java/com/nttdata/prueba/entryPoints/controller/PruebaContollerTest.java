package com.nttdata.prueba.entryPoints.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nttdata.prueba.entryPoints.error.RestExceptionHandler;
import com.nttdata.prueba.model.response.ResponsePrueba;
import com.nttdata.prueba.useCase.UseCase;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.math.BigInteger;
import java.time.LocalDate;

@ExtendWith(SpringExtension.class)
@WebMvcTest(PruebaContoller.class)
@ContextConfiguration(classes = {PruebaContoller.class, PruebaContollerTest.class, RestExceptionHandler.class})
class PruebaContollerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private ResponsePrueba responsePrueba;

    @BeforeEach
    void setup() {
        responsePrueba  = new ResponsePrueba().builder()
                .primerNombre("Daniel")
                .segundoNombre("Camilo")
                .primerApellido("Castellanos")
                .segundoApellido("Carreno")
                .telefono(new BigInteger("3223653541"))
                .direccion("Calle 1 # 1 - 1")
                .ciudadResidencia("Bogota")
                .build();
    }

    @Test
    void statusHealthOk() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/api/health")
                .content(objectMapper.writeValueAsString("All ok"))
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void getDataOk() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/api/prueba?numDoc=23445322&tipoDoc=C")
                .content(objectMapper.writeValueAsString(responsePrueba))
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
}